<!DOCTYPE html>
<html lang="az">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"  href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet"  href="css/style.css">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <title>Cihaz Haqqında</title>
</head>

<body class="body-color">

    <!-- header start-->
    <header class="container-fluid header-footer-color">
        <?php include 'header.php'; ?>
    </header>
    <!-- header end-->



    <main class="container pt-5 pb-5">
               
        <!-- Device info start-->
        <section class="container mt-5 mb-5 bg-white round-corner">
            <div class="container p-3 ">

                <h1 class="text-center mt-4">Cihaz Haqqında</h1>
                <div class="row mt-5 pt-4 pb-4">

                    <div class="col-sm-6">
                        <h4 class="text-center text-uppercase">Texnobaba </h4>
                        <h4 class="mt-3">İlk öncə TexnoBabanın nə olduğuna nəzər salaq.  </h4>
                        <p class="fs-4 fst-italic mt-3 ">
                            TexnoBaba insansız çalışan elektromexanik vasitədir. 
                            TexnoBaba qurğusu vasitəsilə investorlar  müxtəlif ərazilərdə yaşayan uşaqların ehtiyac duyduğu robot setləri və ya başqa bu kimi məmulatları görə biləcək  və onlara investisiya (ianə ) edə biləcəklər.
                            TexnoBaba qurğuları bir başa öz platforması ilə əlaqədar olduğundan ,  hansı ərazidəki şagirdin nə istədiyini görmək və rahatlıqla ianə etmək olacaq. Rəqəmsal platformamızda əks olunan bu məlumatlar sahəsində, uşaqlar üçün istədikləri robot setlərini təmin etməklə yanaşı onların təhsildə olan müasir innovativ yeniliklərdən istifadəsinə geniş zəmin yaratmış olacağıq .
                            Rəqəmsal innovasiya sahəsində ideyası olan məktəblilər və gənclərin öz ideyalarına əsasən ortaya qoymaq istədikləri  layihəyə investorlar tərəfindən dəstək olunacaq bir platformanı təklif edirik . (texnobaba.com)     
                        </p>
                    </div>

                    <div class="col-sm-6 ">
                        <img class="img-thumbnail " src="img/device.jpg" alt="texnobaba picture">
                    </div>

                </div>
            </div>
        </section>
        <!-- Device info end-->

    </main>



    <!-- footer start-->
    <footer class="container-fluid header-footer-color">
        <?php include 'footer.php'; ?>
    </footer>
    <!-- footer end-->

    <script src="js/bootstrap.min.js"> </script>
</body>

</html>