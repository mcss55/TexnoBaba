<!DOCTYPE html>
<html lang="az">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"  href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet"  href="css/style.css">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <title>Texnobaba - Nərimanov</title>
</head>

<body class="body-color">

    <!-- header start-->
    <header class="container-fluid header-footer-color">
        <?php include 'header.php'; ?>
    </header>
    <!-- header end-->


    <main class="container pt-5 pb-5">
               
        <!--  start-->
        <section class="container mt-5 mb-5 bg-white round-corner">
            
            <div class="container px-3 py-5 ">

                <h1 class="text-center">Texnobaba - Nərimanov</h1>
                
                <!-- item 1 start -->
                <div class="row fs-5 mt-5 border">

                    <!--image start-->
                    <div class="col-sm-4 ">
                        <img class="img-thumbnail" src="img/items/planets.jpg" alt="planets">
                    </div>
                    <!--image end-->

                    <!--description start-->
                    <div class="col-sm-4 pt-3  text-center">
                        <h3>Planetlər</h3>
                        <p>Günəş sistemi dəsti <br>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt obcaecati ad amet aperiam sit, tenetur, vero distinctio adipisci quam 
                        </p>
                    </div>
                    <!--description end-->

                    <!--availability start-->
                    <div class="col-sm-4 pt-5 border-start text-center">
                        <p class="d-inline ">Hal hazırda:</p>
                        <p class="d-inline  fw-bold text-success">Mövcuddur</p> <br>
                        <a href="#" class="btn btn-success my-4 "> Müraciət et </a> 
                    </div>
                    <!--availability end-->

                </div>
                <!-- item 1 end -->


                <!-- item 2 start -->
                <div class="row fs-5 mt-3  border">

                    <!--image start-->
                    <div class="col-sm-4 ">
                        <img class="img-thumbnail" src="img/items/level_alarm.jpg" alt="water level alarm">
                    </div>
                    <!--image end-->

                    <!--description start-->
                    <div class="col-sm-4 pt-3  text-center">
                        <h3>Su səviyyəsi sensoru </h3>
                        <p> 
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt obcaecati ad amet aperiam sit, tenetur, vero distinctio adipisci quam                             
                        </p>
                    </div>
                    <!--description end-->

                    <!--availability start-->
                    <div class="col-sm-4 pt-5 border-start text-center">
                        <p class="d-inline ">Hal hazırda:</p>
                        <p class="d-inline  fw-bold text-danger">Mövcud deyil</p> <br>
                        <a href="#" class="btn btn-success my-4 "> Müraciət et </a> 
                    </div>
                    <!--availability end-->

                </div> 
                <!-- item 2 end -->


                <!-- item 3 start -->
                <div class="row fs-5 mt-3  border">

                    <!--image start-->
                    <div class="col-sm-4 ">
                        <img class="img-thumbnail" src="img/items/block_crane.jpg" alt="block crane">
                    </div>
                    <!--image end-->

                    <!--description start-->
                    <div class="col-sm-4 pt-3  text-center">
                        <h3>Blok kran sistemi </h3>
                        <p> 
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt obcaecati ad amet aperiam sit, tenetur, vero distinctio adipisci quam                             
                        </p>
                    </div>
                    <!--description end-->

                    <!--availability start-->
                    <div class="col-sm-4 pt-5 border-start text-center">
                        <p class="d-inline ">Hal hazırda:</p>
                        <p class="d-inline  fw-bold text-success">Mövcuddur</p> <br>
                        <a href="#" class="btn btn-success my-4 "> Müraciət et </a> 
                    </div>
                    <!--availability end-->

                </div> 
                <!-- item 3 end -->


                <!-- item 4 start -->
                <div class="row fs-5 mt-3  border">

                    <!--image start-->
                    <div class="col-sm-4">
                        <img class="img-thumbnail" src="img/items/water_dispenser.jpg" alt="water dispenser">
                    </div>
                    <!--image end-->

                    <!--description start-->
                    <div class="col-sm-4 pt-3  text-center">
                        <h3>Su dispenseri </h3>
                        <p> 
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt obcaecati ad amet aperiam sit, tenetur, vero distinctio adipisci quam                             
                        </p>
                    </div>
                    <!--description end-->

                    <!--availability start-->
                    <div class="col-sm-4 pt-5 border-start text-center">
                        <p class="d-inline ">Hal hazırda:</p>
                        <p class="d-inline  fw-bold text-success">Mövcuddur</p> <br>
                        <a href="#" class="btn btn-success my-4 "> Müraciət et </a> 
                    </div>
                    <!--availability end-->

                </div> 
                <!-- item 4 end -->


                <!-- item 5 start -->
                <div class="row fs-5 mt-3  border">

                    <!--image start-->
                    <div class="col-sm-4 ">
                        <img class="img-thumbnail" src="img/items/auto_door.jpg" alt="auto door">
                    </div>
                    <!--image end-->

                    <!--description start-->
                    <div class="col-sm-4 pt-3  text-center">
                        <h3>Avto qapı </h3>
                        <p> 
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt obcaecati ad amet aperiam sit, tenetur, vero distinctio adipisci quam                             
                        </p>
                    </div>
                    <!--description end-->

                    <!--availability start-->
                    <div class="col-sm-4 pt-5 border-start text-center">
                        <p class="d-inline ">Hal hazırda:</p>
                        <p class="d-inline  fw-bold text-danger">Mövcud deyil</p> <br>
                        <a href="#" class="btn btn-success my-4 "> Müraciət et </a> 
                    </div>
                    <!--availability end-->

                </div> 
                <!-- item 5 end -->


                <!-- item 6 start -->
                <div class="row fs-5 mt-3  border">

                    <!--image start-->
                    <div class="col-sm-4 ">
                        <img class="img-thumbnail" src="img/items/watering_kit.jpg" alt="watering kit">
                    </div>
                    <!--image end-->

                    <!--description start-->
                    <div class="col-sm-4 pt-3  text-center">
                        <h3>Avtomatik gül sulayan </h3>
                        <p> 
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt obcaecati ad amet aperiam sit, tenetur, vero distinctio adipisci quam                             
                        </p>
                    </div>
                    <!--description end-->

                    <!--availability start-->
                    <div class="col-sm-4 pt-5 border-start text-center">
                        <p class="d-inline ">Hal hazırda:</p>
                        <p class="d-inline  fw-bold text-success">Mövcuddur</p> <br>
                        <a href="#" class="btn btn-success my-4 "> Müraciət et </a> 
                    </div>
                    <!--availability end-->

                </div> 
                <!-- item 6 end -->

                <!-- item 7 start -->
                <div class="row fs-5 mt-3  border">

                    <!--image start-->
                    <div class="col-sm-4 ">
                        <img class="img-thumbnail" src="img/items/drone.jpg" alt="drone">
                    </div>
                    <!--image end-->

                    <!--description start-->
                    <div class="col-sm-4 pt-3  text-center">
                        <h3>Dron</h3>
                        <p> 
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt obcaecati ad amet aperiam sit, tenetur, vero distinctio adipisci quam                             
                        </p>
                    </div>
                    <!--description end-->

                    <!--availability start-->
                    <div class="col-sm-4 pt-5 border-start text-center">
                        <p class="d-inline ">Hal hazırda:</p>
                        <p class="d-inline  fw-bold text-success">Mövcuddur</p> <br>
                        <a href="#" class="btn btn-success my-4 "> Müraciət et </a> 
                    </div>
                    <!--availability end-->

                </div> 
                <!-- item 7 end -->


            </div>
        </section>
        <!--  end-->

    </main>

    <!-- footer start-->
    <footer class="container-fluid header-footer-color">
        <?php include 'footer.php'; ?>
    </footer>
    <!-- footer end-->

    <script src="js/bootstrap.min.js"> </script>
</body>

</html>