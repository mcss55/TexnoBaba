package com.mcss.texnobaba;

import javax.xml.crypto.Data;
import java.sql.SQLException;

public class test {
    public static void main(String[] args) throws SQLException {
        Sagird s=new Sagird("emiijlsad","hemhzsiiadeyev","emiiiisadl@4564.com","189");
        DataBaseConnection.addSagirdToDb(s);
        DataBaseConnection.getAllData("SHAGIRD");
        }
    }

