package com.mcss.texnobaba;

import org.springframework.boot.jdbc.DatabaseDriver;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class Contoller {
    @GetMapping("/")
    public String index(){
        return "index";
    }
    @RequestMapping("/index.html")
    public ModelAndView changeLocale() {
        RedirectView redirectView = new RedirectView("/");
        redirectView.setExposePathVariables(false);
        return new ModelAndView(redirectView);
    }
    @GetMapping("/header.html")
    public String header(){
        return "header";
    }
    @GetMapping("/contact.html")
    public String contact(){
        return "contact";
    }
    @GetMapping("/footer.html")
    public String footer(){
        return "footer";
    }
    @GetMapping("/ckeck_info.html")
    public String ckeck_infoHtml(Model model){
        return "ckeck_info";
    }
    @PostMapping("/ckeck_info")
    public String checkUser(Model model, @RequestParam String name,
                            @RequestParam String surname,
                            @RequestParam String email,
                            @RequestParam String person,
                            @RequestParam String password1,
                            @RequestParam String password2) throws InterruptedException {
        if (person.equals("pupil")) {
            boolean checkHave=false;
            for (Sagird sagird : Sagird.getSagirdlerList()) {
                if (sagird.getEmail().equals(email)) {
                    checkHave=true;
                }else {
                    checkHave=false;
                }
            }
            if (!checkHave) {
                Sagird sagird=new Sagird(name,surname,email,password2);
                Sagird.addSagirdler(sagird);
                checkHave=false;
                model.addAttribute("errorMsg","Qeydiyyatdan kechdiniz!");

                return ckeck_infoHtml(model);
            }else{
                model.addAttribute("errorMsg","Bu email artiq movcuddur!");
                return ckeck_infoHtml(model);
            }
        }else {
            boolean checkHave=false;
            for (TohfeVeren tohfeVeren : TohfeVeren.getTohveVerenlerList()) {
                if (tohfeVeren.getEmail().equals(email)) {
                    checkHave=true;
                }else {
                    checkHave=false;
                }
            }
            if (!checkHave) {
                TohfeVeren tohfeVeren=new TohfeVeren(name,surname,email,password2);
                TohfeVeren.addTohfeVeren(tohfeVeren);
                checkHave=true;
                model.addAttribute("errorMsg","Qeydiyyatdan kechdiniz!");
                return ckeck_infoHtml(model);
            }else{
                model.addAttribute("errorMsg","Istifadechiden var!");
                return ckeck_infoHtml(model);
            }
        }
    }
}
