package com.mcss.texnobaba;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class Contoller {
    @GetMapping("/")
    public String index(){
        return "header";
    }
    @PostMapping("/ckeck_info")
    @ResponseBody
    public String checkUser(@RequestParam String name,
                            @RequestParam String surname,
                            @RequestParam String email,
                            @RequestParam String person,
                            @RequestParam String password1,
                            @RequestParam String password2){
        if (person.equals("pupil")) {
            boolean checkHave=false;
            for (Sagird sagird : Sagird.getSagirdlerList()) {
                if (sagird.getEmail().equals(email)) {
                    checkHave=true;
                }else {
                    checkHave=false;
                }
            }
            if (!checkHave) {
                if(!password1.equals(password2)){
                    return "Sifreler bir biri ile uygun deyil!";
                }else {
                    Sagird sagird=new Sagird(name,surname,email,person,password2);
                    Sagird.addSagirdler(sagird);
                    for (Sagird sagir : Sagird.getSagirdlerList()) {
                        System.out.println(sagird.getId());
                        System.out.println(sagird.getEmail());
                        System.out.println(sagird.getName());
                    }
                    return "Qeydiyyatdan kechdiniz!";
                }
            }else{
                return "Istifadechiden var!";
            }
        }else {

        }
    }
}
