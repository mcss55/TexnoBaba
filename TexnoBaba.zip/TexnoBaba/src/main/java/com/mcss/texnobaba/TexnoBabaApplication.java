package com.mcss.texnobaba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TexnoBabaApplication {

    public static void main(String[] args) {
        SpringApplication.run(TexnoBabaApplication.class, args);
    }

}
