        <!-- footer -->
        <div class="container pt-5 pb-3">
            <div class="row"> 
                <div class="col-sm-3  h6">
                    <a class="nav-link text-white underline " href="index.php">Əsas səhifə</a>
               </div>

                <div class="col-sm-3  h6">
                    <a class="nav-link text-white underline " href="about.php">Haqqımızda</a>
               </div>

                <div class="col-sm-3  h6">
                    <a class="nav-link text-white underline" href="contact.php">Əlaqə</a>
                </div>

                <div class="col-sm-3 text-end ">
                    <a href="http://www.facebook.com/robot.org.az" target="_blank" class="text-decoration-none"> <img class="p-1" src="img/icons/facebook_logo.png"  alt="fb_icon"> </a>
                    <a href="https://instagram.com/robot.org.az" target="_blank" class="text-decoration-none"> <img class="p-1" src="img/icons/instagram_Logo.png" alt="instagram_icon"> </a>
                    <a href="https://www.youtube.com/channel/UCwRZs0XZIsqAV3mCX0eftbg" target="_blank" class="text-decoration-none"> <img class="p-1" src="img/icons/youtube_logo.png"   alt="youtube_icon"> </a>
                </div>
            </div>

           
            
            <div class="row mt-5 pt-4 border-top border-secondary">
                <div class="col-sm-12 text-white-50 text-center h6">
                    <p>Texnobaba © 2022 Site by AREA - Rufat</p>
                </div>
            </div>

        </div>