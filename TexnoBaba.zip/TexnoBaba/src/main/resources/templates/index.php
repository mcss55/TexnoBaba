<!DOCTYPE html>
<html lang="az">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"  href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet"  href="css/style.css">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <title>Texnobaba - Əsas səhifə</title>
</head>

<body class="body-color">

    <!-- header start-->
    <header class="container-fluid  header-footer-color">
        <?php include 'header.php' ?>
    </header>
    <!-- header end-->


    <main class="container pt-5 pb-5">

        <!-- Youtube video start-->        
            <div class="row text-center justify-content-center">            
                <div class="col-sm-9">

                    <h1>"Texnobaba" məhz siz şagirdləri sevindirməyə gəlir.</h1>
                      
                        <div id="carouselControl" class="carousel slide mt-5 mb-4" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active" data-bs-interval="60500">                                    
                                    <iframe  class="w-100"  height="500" src="https://www.youtube.com/embed/bcAYyk36lmQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>    
                                </div>
                                <div class="carousel-item" data-bs-interval="25000">
                                    <iframe  class="w-100"  height="500" src="https://www.youtube.com/embed/Om38K2tBkrA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </div>                                
                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#carouselControl" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#carouselControl" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                </div>  
            </div>
        <!-- Youtube video end-->

        
        <div class="row px-4 pb-4 text-center">
            <div class="col">                
                <p class="mt-4 fs-3">
                    Əziz şagirdlər, əgər siz gələcəyin mühəndisi olmaq istəyirsinizsə və ailəniz sizə maddi baxımdan dəstək ola bilmirsə, o zaman səhifəmizdə gördüyünüz mühəndislik məhsullarını "Texnobaba"-ya istək məktubu yazmaqla əldə edə bilərsiniz. <br>
                    Bunun üçün qeydiyyatdan keçmək və ona istək məktubu yazmaq lazımdır. 
                </p>
            </div>
        </div>
       
        
        <section class="container mt-5 mb-5 bg-white round-corner">
            <div class="container p-4 ">

                <div class="row px-4 pb-4">
                    <div class="col ">
                        <h2>Sənə yaxın olan məntəqəni seç</h2>
                    </div>
                </div>

                <!-- Locations start-->
                <div class="row mt-4 text-center">
                    

                    <!--Baku start--> 
                    <div class="col ">                                  
                        <a class="btn fs-3" data-bs-toggle="collapse" href="#collapseBaku" role="button" aria-expanded="false" aria-controls="collapseBaku">
                            <img src="img/cities/robot_pic.jpg" class="img-thumbnail round-corner" alt="Baki">
                            <p class="mt-3 mb-4">Bakı</p>
                        </a> 
                        <div class="collapse mt-4" id="collapseBaku">
                          <a href="baki_nerimanov.php" class="btn btn-outline-primary fs-5 d-block mb-3">Nərimanov</a>
                          <a href="baki_qarayev.php" class="btn btn-outline-primary fs-5 d-block mb-3">Qarayev</a>
                          <a href="baki_bineqedi.php" class="btn btn-outline-primary fs-5 d-block mb-3">Binəqədi</a>
                        </div>                                  
                    </div> 
                    <!--Baku end-->
                                        
                    
                    <!--Sumqayit start--> 
                    <div class="col">                                    
                        <a class="btn fs-3" data-bs-toggle="collapse" href="#collapseSumqayit" role="button" aria-expanded="false" aria-controls="collapseSumqayit">
                            <img src="img/cities/robot_pic.jpg" class="img-thumbnail round-corner" alt="Sumqayit">
                            <p class="mt-3 mb-4">Sumqayıt</p>
                        </a>
                        <div class="collapse mt-4" id="collapseSumqayit">
                          <a href="sumqayit_mikrorayon3.php" class="btn btn-outline-primary fs-5 d-block mb-3">3-cü mikrorayon</a>
                          <a href="sumqayit_mikrorayon4.php" class="btn btn-outline-primary fs-5 d-block mb-3">4-cü mikrorayon</a>
                          <a href="sumqayit_mikrorayon9.php" class="btn btn-outline-primary fs-5 d-block mb-3">9-cu mikrorayon</a>
                        </div>                                   
                    </div> 
                    <!--Sumqayit end--> 
                    

                    <!--Gence start--> 
                    <div class="col">                                    
                        <a class="btn fs-3" data-bs-toggle="collapse" href="#collapseGence" role="button" aria-expanded="false" aria-controls="collapseGence">
                            <img src="img/cities/robot_pic.jpg" class="img-thumbnail round-corner" alt="Gence">
                            <p class="mt-3 mb-4 ">Gəncə</p>
                        </a>
                        <div class="collapse mt-4" id="collapseGence">
                          <a href="gence_a_sehhet.php" class="btn btn-outline-primary fs-5 d-block mb-3">Abbas Səhhət</a>
                          <a href="gence_ataturk.php" class="btn btn-outline-primary fs-5 d-block mb-3">Atatürk pr.</a>
                          <a href="gence_m_univermaq.php" class="btn btn-outline-primary fs-5 d-block mb-3">Mərkəzi Ünivermaq</a>
                        </div>                                                                      
                    </div> 
                    <!--Gence end--> 


                    <!--Zaqatala start--> 
                    <div class="col">                                    
                        <a class="btn fs-3" data-bs-toggle="collapse" href="#collapseZaqatala" role="button" aria-expanded="false" aria-controls="collapseZaqatala">
                            <img src="img/cities/robot_pic.jpg" class="img-thumbnail round-corner" alt="Zaqatala">
                            <p class="mt-3 mb-4 ">Zaqatala</p>
                        </a>
                        <div class="collapse mt-4" id="collapseZaqatala">
                          <a href="zaqatala_azerbaycan_pr.php" class="btn btn-outline-primary fs-5 d-block mb-3">Azerbaycan pr.</a>
                          <a href="zaqatala_qaladuzu.php" class="btn btn-outline-primary fs-5 d-block mb-3">Qaladüzü</a>
                          <a href="zaqatala_yuxari_tala.php" class="btn btn-outline-primary fs-5 d-block mb-3">Yuxari tala</a>
                        </div>                                                                                                         
                    </div> 
                    <!--Zaqatala end--> 


                </div>
                <!-- Locations end-->

            </div>
        </section>
        

    </main>


    <!-- footer start-->
    <footer class="container-fluid header-footer-color">
        <?php include 'footer.php'; ?>
    </footer>
    <!-- footer end-->

    <script src="js/bootstrap.min.js"> </script>
</body>

</html>