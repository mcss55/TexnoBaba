<!DOCTYPE html>
<html lang="az">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"  href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet"  href="css/style.css">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <title>Bizimlə əlaqə</title>
</head>

<body class="body-color">

    <!-- header start-->
    <header class="container-fluid header-footer-color">
        <?php include 'header.php'; ?>
    </header>
    <!-- header end-->


    <main class="container pt-5 pb-5">
               
        <!-- About start-->
        <section class="container mt-5 mb-5 bg-white round-corner">
            <div class="container p-5 ">
                <div class="row px-4 pb-4">

                    <h1 class="text-center mt-3">Bizimlə əlaqə</h1>

                    <div class="col-sm-6 mt-5 fs-4 text-center">  

                        <address class="">
                            Bakı şəhəri, 7ci mkr, S.S.Axundov 13/37<br>                            
                        </address>

                        <p class="mb-5">
                            Web:
                            <a href="https://www.robot.org.az" target="_blank">www.robot.org.az</a><br>
                            Email:
                            <a href="mailto:info@robot.org.az">info@robot.org.az </a><br>
                            Tel:
                            <a href="tel:+99470-256-64-66">+994 70 256-64-66</a>
                        </p>

                        <a href="http://www.facebook.com/robot.org.az" target="_blank" class="text-decoration-none"> <img class="p-1" src="img/icons/facebook_logo.png"  alt="fb_icon"> </a>
                        <a href="https://instagram.com/robot.org.az" target="_blank" class="text-decoration-none"> <img class="p-1" src="img/icons/instagram_Logo.png" alt="instagram_icon"> </a>
                        <a href="https://www.youtube.com/channel/UCwRZs0XZIsqAV3mCX0eftbg" target="_blank" class="text-decoration-none"> <img class="p-1" src="img/icons/youtube_logo.png"   alt="youtube_icon"> </a>
                        
                    </div>

                    <div class="col-sm-6 mt-5">
                        <img class="img-thumbnail" src="img/contact.jpg" alt="">
                    </div>

                </div>

                

            </div>
        </section>
        <!-- About end-->

    </main>

    <!-- footer start-->
    <footer class="container-fluid header-footer-color">
        <?php include 'footer.php'; ?>
    </footer>
    <!-- footer end-->

    <script src="js/bootstrap.min.js"> </script>
</body>

</html>