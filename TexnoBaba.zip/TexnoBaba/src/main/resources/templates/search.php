<?php

echo "<h1>Sorry, i can't search yet.</h1> <p>Go back please</>";




?>