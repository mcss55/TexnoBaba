 
<!-- Header start-->
<div class="container pb-5 ">
    <div class="row">

        <!-- Logo start-->
        <div class="col-sm-4 mt-4 ps-0 ">
            <a href="index.php"><img src="img/icons/logo.png" alt="texnobaba logo" width="195"></a>
        </div>
        <!-- Logo end-->

        <!-- Menu Top start -->
        <div class="col-sm-5 mt-4  ">
            <ul class="nav h6 ">
                <li class="nav-item">
                    <a class="nav-link text-white underline " href="index.php">Əsas səhifə</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white underline" href="about.php">Haqqımızda</a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link text-white underline" href="contact.php">Əlaqə</a>
                </li>
            </ul>
        </div>
        <!-- Menu Top end -->

        <!-- Login & Registration start-->
        <div class="col-sm-3 mt-4">
            <ul class="nav h6 justify-content-end">
                <li class="nav-item hover-underline">
                    <a class="nav-link text-white" data-bs-toggle="modal" href="#signUpModal">Qeydiyyat</a>
                </li>
                <li class="nav-item hover-underline">
                    <a class="nav-link text-white" data-bs-toggle="modal" href="#signInModal" >Giriş</a>
                </li>
            </ul>
        </div>
        <!-- Login & Registration end-->

        <!-- Sign up Modal start-->
        <div class="modal fade" id="signUpModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content rounded-3 shadow">

                    <div class="modal-header p-5 pb-4 border-bottom-0">
                        <h2 class="fw-bold mb-0">Yeni istifadəçi</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body p-5 pt-0">
                        <form action="ckeck_info" method="post">
                            <div class="form-floating mb-3">
                                <input type="text" class="rounded-3 form-control" name="name" id="floatingInput" placeholder="Name">
                                <label for="floatingInput">Adınız</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" class="rounded-3 form-control" name="surname" id="floatingInput" placeholder="Surname">
                                <label for="floatingInput">Soyadınız</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="email" class="rounded-3 form-control" name="email" id="floatingInput" placeholder="Email">
                                <label for="floatingInput">Email ünvan</label>
                            </div>                                                        
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="radio" name="person" value="pupil" id="pupil">
                                <label class="form-check-label" for="pupil">
                                    Şagird
                                </label>
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="radio" name="person" value="contributor" id="contributor">
                                <label class="form-check-label" for="contributor">
                                    Töhfə verən
                                </label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="password" class="form-control rounded-3" name="password1" id="floatingPassword" placeholder="Password">
                                <label for="floatingPassword">Şifrəniz</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="password" class="form-control rounded-3" name="password2" id="floatingPassword" placeholder="Password2">
                                <label for="floatingPassword">Şifrənin təkrarı</label>
                            </div>

                            <button class="w-100 mt-4 mb-3 btn btn-lg rounded-4 btn-primary" type="submit">Qeydiyyatı tamamla</button>
                                                    
                        </form>
                    </div> 
                </div>      
            </div>
        </div>
        <!-- Sign up Modal end--> 

        <!-- Sign in Modal start-->
        <div class="modal fade" id="signInModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content rounded-3 shadow">

                    <div class="modal-header p-5 pb-4 border-bottom-0">
                        <h2 class="fw-bold mb-0">Sistemə Giriş</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body p-5 pt-0">
                        <form action="ckeck_info.php" method="post">
                            <div class="form-floating mb-3">
                                <input type="email" class="rounded-3 form-control" name="user" id="floatingInput" placeholder="Login">
                                <label for="floatingInput">Email ünvan</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="password" class="form-control rounded-3" name="password" id="floatingPassword" placeholder="Password">
                                <label for="floatingPassword">Şifrə</label>
                            </div>
                            <button class="w-100 mb-2 btn btn-lg rounded-4 btn-primary" type="submit">Daxil ol</button>
                            
                            <hr class="my-4">
                            <h2 class="fs-5 fw-bold mb-3">Sosial şəbəkə vasitəsilə giriş</h2>

                            <button class="w-100 py-2 mb-2 btn btn-outline-dark rounded-4" type="submit">
                                Google
                            </button>
                            
                            <button class="w-100 py-2 mb-2 btn btn-outline-primary rounded-4" type="submit">
                                Facebook
                            </button>
                        </form>
                    </div> 
                </div>      
            </div>
        </div>
        <!-- Sign in Modal end-->

    </div>



    <!-- Search field start-->
    <form action="search.php">
        <div class="row ">

            <div class="col-sm-3 mt-4">
                <select class="form-select" name="city">
                    <option value="All">Mərkəzlər</option>
                    <option value="Baku">Bakı</option>
                    <option value="Sumqayit">Sumqayıt</option>
                    <option value="Gence">Gəncə</option>
                    <option value="Zaqatala">Zaqatala</option>
                </select>
            </div>

            <div class="col-sm-6 mt-4 ">
                <input class="form-control" type="search" placeholder="Axtarış" name="search">
            </div>

            <div class="col-sm-3 mt-4 d-grid " >
                <button class="btn btn-success" type="submit"> Axtar </button> 
            </div>
            

        </div>
    </form>
    <!-- Search field end-->

    <!-- Posting an ad button start-->
    <div class="row mt-4 ">
        <div class="col-sm-4 ">
            <a href="device_info.php" class="link-light h6 underline ">Cihaz haqqında</a>
        </div>

        <div class="col-sm-8 d-grid justify-content-end">
            <a href="#" class="btn btn-warning"> + İANƏ EDİN </a> 
        </div>
    </div>
    <!-- Posting an ad button end-->

</div>
<!-- Header end-->



