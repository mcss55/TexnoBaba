package com.mcss.texnobaba;

public class test {
    public static void main(String[] args) {
        Sagird s=new Sagird("emil","hemzeyev","emil@cmasd.com","Sagird","123456789");
        Sagird s1=new Sagird("emil","hemzeyev","emil@cmasd.com","Sagird","123456789");
        Sagird s2=new Sagird("emil","hemzeyev","emil@cmasd.com","Sagird","123456789");

        s.addSagirdler(s);
        s.addSagirdler(s1);
        s.addSagirdler(s2);
        for (Sagird sagird : Sagird.getSagirdlerList()) {
            System.out.println(sagird.getName());
        }
    }
}
