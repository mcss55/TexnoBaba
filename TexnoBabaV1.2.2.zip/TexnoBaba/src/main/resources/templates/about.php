<!DOCTYPE html>
<html lang="az">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"  href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet"  href="css/style.css">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <title>Haqqımızda</title>
</head>

<body class="body-color">

    <!-- header start-->
    <header class="container-fluid header-footer-color">
        <?php include 'header.php'; ?>
    </header>
    <!-- header end-->


    <main class="container pt-5 pb-5">
               
        <!-- About start-->
        <section class="container mt-5 mb-5 bg-white round-corner">
            
            <div class="container p-3 ">

                <div class="row pb-4">

                    <h1 class="text-center mt-4">Haqqımızda</h1>

                    <div class="col mt-5">
                        <h4 class="text-center">TEKNOFEST <br> 
                            AEROKOSMİK VƏ TEXNOLOGİYA FESTİVALI<br>
                            LAYİHƏ HAQQINDA TƏFƏRRÜATLI HESABAT
                        </h4>
                        <h4 class="mt-5">KOMANDA ADI:   BACARANLAR <br>
                            LAYİHƏNİN ADI:  TEXNOBABA (www.texnobaba.com ) 
                        </h4> 
                        <h5 class="mt-4">
                            Komanda üzvləri: <br>
                            Proqramlaşdırma və 3D modelləmə mühəndisi : Məhəmməd Hacıyev <br>
                            Proqramlaşdırma mühəndisi : Rüfət Əliyev <br>
                            Proqram kordinatoru : Sulxayeva Məryəmana <br>
                            Mexanika mühəndisi : Elmar Məmmədov <br>
                            Elektronika mühəndisi : Tural Əliyev <br>
                            Məsləhətçi Mentor  : Rəhman Rəsulzadə <br>
                        </h5>                       
                        <p class="fs-4 fst-italic mt-5">İqtisadi vəziyyətin pis olması səbəbindən 
                            bir çox ərazilərdə  şagirdlər  müasir innovativ təhsil 
                            texnologiyalarını öyrənə  bilmir. Bu, şagirdlərin  karyera əsaslı 
                            məqsədlərini qurmaqda güclü tərəflərinə təsir edən şəhər və kənd 
                            rəqəmsal uçurumunu əmələ gətirir. <br>
                            Layihənin həll etdiyi problem  çox geniş bir dəsti xətt əhatə edir.
                            Nəzərə alsaq ki , gənclərimizin yaratmaq, qurmaq, inkişafa meyillilik
                            qabiliyyəti olduqca yüksəkdir . Bizim Layihəmizin onların bu ideyalarını 
                            həyata keçirməyə dəstək verməklə yanaşı həmdə təhsildə innovativ 
                            yeniliklərin tətbiqinə gətirib çıxarır. <br> <br>

                            İlk öncə TexnoBabanın nə olduğuna nəzər salaq. <br> 
                            TexnoBaba insansız çalışan elektromexanik vasitədir. 
                            Rəqəmsal innovasiya sahəsində ideyası olan məktəblilər və gənclərin öz ideyalarına əsasən ortaya qoymaq istədikləri  layihəyə investorlar tərəfindən dəstək olunacaq bir platformani təklif edirik .(texnobaba.com)
                            TexnoBaba qurğusu vasitəsilə investorlar  müxtəlif ərazilərdə yaşayan uşaqların ehtiyac duyduğu robot setləri və ya başqa bu kimi məmulatları görə biləcək  və onlara investisiya (ianə ) edə biləcəklər.
                            TexnoBaba qurğularını bir başa öz platforması ilə əlaqədar olduğundan ,  hansı ərazidəki şagirdin nə istədiyini görə,  rahatlıqla ianə edilə biləcək. Rəqəmsal platformamızda əks olunan bu məlumatlar sahəsində , uşaqlar üçün istədikləri robot setlərini təmin etməklə yanaşı onların təhsildə olan müasir innovativ yeniliklərdən istifadəsinə geniş zəmin yaratmış olacağıq .
                        </p>
                        <p>
                            

                        </p>

                        <img class="img-thumbnail mt-4" src="img/two_hands.jpg" alt="two hands">

                    </div>

                </div>

                

            </div>
        </section>
        <!-- About end-->

    </main>

    <!-- footer start-->
    <footer class="container-fluid header-footer-color">
        <?php include 'footer.php'; ?>
    </footer>
    <!-- footer end-->

    <script src="js/bootstrap.min.js"> </script>
</body>

</html>