package com.mcss.texnobaba;

import java.util.ArrayList;

public class TohfeVeren {
    public String name;
    public static int id;
    public String surname;
    public String email;
    public String person;
    public String password;
    public static ArrayList<TohfeVeren> tohveVerenlerList =new ArrayList<>();

    public TohfeVeren(String name, String surname, String email, String person, String password) {
        this.id=Sagird.getId()+1;
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.person = person;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static int getId() {
        return id;
    }

    public static void setId(int id) {
        TohfeVeren.id = id;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public static ArrayList<TohfeVeren> getTohveVerenlerList() {
        return tohveVerenlerList;
    }

    public static void setTohveVerenlerList(ArrayList<TohfeVeren> tohfeVerenlerList) {
        tohveVerenlerList = tohfeVerenlerList;
    }
    public static void addTohfeVeren(TohfeVeren tohfeVeren){
        tohveVerenlerList.add(tohfeVeren);
    }
}
