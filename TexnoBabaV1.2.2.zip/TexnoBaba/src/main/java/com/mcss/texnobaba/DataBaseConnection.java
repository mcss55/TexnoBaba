package com.mcss.texnobaba;

import java.sql.*;

public class DataBaseConnection {
    static Connection connection = null;
    static Statement statement = null;
    static ResultSet resultSet = null;
    public static void makeJDBCConnection(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException exception) {
            System.out.println("Oracle Driver Class Not found Exception: " + exception.toString());
        }
        DriverManager.setLoginTimeout(5);
        try {
            connection = DriverManager.getConnection("jdbc:mysql://109.94.209.16:3306/texno_dp","web_db","web_db");
        } catch (SQLException e) {
            System.out.println("Connection Failed! Check output console");
            e.printStackTrace();
        }
    }

    public static void addSagirdToDb(Sagird sagird) throws SQLException {
        makeJDBCConnection();
        statement = connection.createStatement();
        int id= sagird.getId();
        String s[]=new String[]{"'"+sagird.getName()+"'","'"+sagird.getSurname()+"'","'"+sagird.getEmail()+"'", "'"+sagird.getPassword()+"'"};
        String query=String.join(",",s);
        resultSet = statement.executeQuery(String.format("INSERT INTO `shagird`(`ID`, `NAME`, `SURNAME`, `EMAIL`, `PASSWORD`) VALUES (%d,%s)",id,query));
        if (resultSet.next()) {
            System.out.println("Employee Details: " + resultSet.getInt(1));
            System.out.println("Employee Details: " + resultSet.getString(2));
            System.out.println("Employee Details: " + resultSet.getString(3));
            System.out.println("Employee Details: " + resultSet.getString(4));
            System.out.println("Employee Details: " + resultSet.getString(5));
        } else {
            throw new SQLException("Can NOT retrieve Employee details from table 'CrunchifyEmployee'");
        }
    }

    public static void getAllData(String s) throws SQLException {
        makeJDBCConnection();
        statement = connection.createStatement();
        resultSet = statement.executeQuery("SELECT * FROM `shagird`");
        if (resultSet.next()) {
            System.out.println("Employee Details: " + resultSet.getInt(1));
            System.out.println("Employee Details: " + resultSet.getString(2));
            System.out.println("Employee Details: " + resultSet.getString(3));
            System.out.println("Employee Details: " + resultSet.getString(4));
            System.out.println("Employee Details: " + resultSet.getString(5));
        } else {
            throw new SQLException("Can NOT retrieve Employee details from table 'CrunchifyEmployee'");
        }
    }
    public static void main(String[] args) throws SQLException {

    }
}
