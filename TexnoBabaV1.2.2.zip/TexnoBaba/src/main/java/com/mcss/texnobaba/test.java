package com.mcss.texnobaba;

import java.sql.SQLException;

public class test {
    public static void main(String[] args) throws SQLException {
        Sagird s=new Sagird("emil","hemzeyev","emil@cmasd.com","Sagird","123456789");
        Sagird s1=new Sagird("emil","hemzeyev","emil@cmasd.com","Sagird","123456789");
        Sagird s2=new Sagird("emil","hemzeyev","emil@cmasd.com","Sagird","123456789");
        DataBaseConnection.addSagirdToDb(s2);
        }
    }

