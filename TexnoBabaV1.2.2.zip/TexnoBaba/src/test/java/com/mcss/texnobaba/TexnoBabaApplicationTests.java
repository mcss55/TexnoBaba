package com.mcss.texnobaba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TexnoBabaApplicationTests {

    @Test
    void contextLoads() {
    }

}
