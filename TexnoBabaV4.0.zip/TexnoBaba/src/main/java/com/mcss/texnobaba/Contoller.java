package com.mcss.texnobaba;

import org.springframework.boot.jdbc.DatabaseDriver;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import javax.xml.crypto.Data;
import java.sql.SQLException;

@Controller
public class Contoller {
    @GetMapping("/")
    public String index(){
        return "index";
    }
    @RequestMapping("/index.html")
    public ModelAndView changeLocale() {
        RedirectView redirectView = new RedirectView("/");
        redirectView.setExposePathVariables(false);
        return new ModelAndView(redirectView);
    }
    @GetMapping("/header.html")
    public String header(){
        return "header";
    }
    @GetMapping("/contact.html")
    public String contact(){
        return "contact";
    }
    @GetMapping("/footer.html")
    public String footer(){
        return "footer";
    }
    @GetMapping("/ckeck_info.html")
    public String ckeck_infoHtml(Model model){
        return "ckeck_info";
    }
    @PostMapping("/ckeck_info")
    public String checkUser(Model model, @RequestParam String name,
                            @RequestParam String surname,
                            @RequestParam String email,
                            @RequestParam String person,
                            @RequestParam String password1,
                            @RequestParam String password2) throws InterruptedException, SQLException {
        if (person.equals("pupil")) {
            if (!DataBaseConnection.checkHaveSigned(email)) {
                Sagird sagird=new Sagird(name,surname,email,password2);
                DataBaseConnection.addSagirdToDb(sagird);
                model.addAttribute("errorMsg","Qeydiyyatdan kechdiniz!");
                return ckeck_infoHtml(model);
            }else{
                model.addAttribute("errorMsg","Bu email artiq movcuddur!");
                return ckeck_infoHtml(model);
            }
        }else {
            if (!DataBaseConnection.checkHaveSigned(email)) {
                TohfeVeren tohfeVeren=new TohfeVeren(name,surname,email,password2);
                DataBaseConnection.addTohfeVerenToDb(tohfeVeren);
                model.addAttribute("errorMsg","Qeydiyyatdan kechdiniz!");
                return ckeck_infoHtml(model);
            }else{
                model.addAttribute("errorMsg","Bu email artiq movcuddur!");
                return ckeck_infoHtml(model);
            }
        }
    }
}
