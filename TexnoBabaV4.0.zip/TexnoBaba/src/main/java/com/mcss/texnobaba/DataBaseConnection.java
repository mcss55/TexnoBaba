package com.mcss.texnobaba;

import java.sql.*;
import java.util.ArrayList;

public class DataBaseConnection {
    static Connection connection = null;
    static Statement statement = null;
    static ResultSet resultSet = null;
    static boolean runOlundu=false;
    public static void makeJDBCConnection(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException exception) {
        }
        if (!runOlundu) {
            DriverManager.setLoginTimeout(4);
            runOlundu=true;
        }
        try {
            connection = DriverManager.getConnection("jdbc:mysql://sql657.main-hosting.eu/u312877431_texnoapp","u312877431_texno","0V/8CNYnfL!");
        } catch (SQLException e) {
            makeJDBCConnection();
        }
    }
    public static void addTohfeVerenToDb(TohfeVeren tohfeVeren) throws SQLException {
        makeJDBCConnection();
        int id= tohfeVeren.getId();
        String s[]=new String[]{"'"+tohfeVeren.getName()+"'","'"+tohfeVeren.getSurname()+"'","'"+tohfeVeren.getEmail()+"'", "'"+tohfeVeren.getPassword()+"'"};
        String query=String.join(",",s);
        statement = connection.createStatement();
        statement.executeUpdate(String.format("INSERT INTO `tohfe_verenler`(`ID`, `NAME`, `SURNAME`, `EMAIL`, `PASSWORD`) VALUES (%d,%s)",id,query));
    }
    public static void addSagirdToDb(Sagird sagird) throws SQLException {
        makeJDBCConnection();

        int id= sagird.getId();
        String s[]=new String[]{"'"+sagird.getName()+"'","'"+sagird.getSurname()+"'","'"+sagird.getEmail()+"'", "'"+sagird.getPassword()+"'"};
        String query=String.join(",",s);
        statement = connection.createStatement();
        statement.executeUpdate(String.format("INSERT INTO `sagirdler`(`ID`, `NAME`, `SURNAME`, `EMAIL`, `PASSWORD`) VALUES (%d,%s)",id,query));
    }

    public static ArrayList<Sagird> getAllDataFromSagirdTable() throws SQLException {
        makeJDBCConnection();
        statement = connection.createStatement();
        resultSet = statement.executeQuery("SELECT * FROM sagirdler");
        if (resultSet.next()) {
            ArrayList<Sagird> arrayList=new ArrayList<>();
            arrayList.add(new Sagird(resultSet.getString(2),resultSet.getString(3),resultSet.getString(4)
            ,resultSet.getString(5)));
            return arrayList;
        } else {
            return null;
        }
    }
    public static ArrayList<TohfeVeren> getAllDataFromTohfeVerenTable() throws SQLException {
        makeJDBCConnection();
        statement = connection.createStatement();
        resultSet = statement.executeQuery("SELECT * FROM tohfe_verenler");
        if (resultSet.next()) {
            ArrayList<TohfeVeren> arrayListT=new ArrayList<>();
            arrayListT.add(new TohfeVeren(resultSet.getString(2),resultSet.getString(3),resultSet.getString(4)
                    ,resultSet.getString(5)));
            return arrayListT;
        } else {
            return null;
        }
    }
    public static boolean checkHaveSigned(String email) throws SQLException {
        makeJDBCConnection();
        statement = connection.createStatement();
        resultSet = statement.executeQuery(String.format("SELECT * FROM sagirdler WHERE EMAIL='%s' UNION ALL SELECT * FROM tohfe_verenler WHERE EMAIL='%s'",email,email));
        if (resultSet.next()) {
            return true;
        } else {
            return false;
        }
    }
    // Login sehifesin radio buttonlar yoxdu
    // Vaxt itkisi olmasin deye 1 funk yaziram(only check)
    public static boolean checklogin(String email,String password) throws SQLException {
        makeJDBCConnection();
        statement = connection.createStatement();
        resultSet = statement.executeQuery(String.format("SELECT 'true' AS 'BOOLEAN' FROM sagirdler WHERE EMAIL='%s' AND PASSWORD='%s';",email,password));
        if (resultSet.next()) {
            return true;
        } else {
            return false;
        }
    }
    public static void main(String[] args) throws SQLException {

    }
}
