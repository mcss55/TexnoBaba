package com.mcss.texnobaba;
import java.sql.SQLException;

public class test {
    public static void main(String[] args) throws SQLException {
        Sagird s=new Sagird("emiijlsad","hemhzsiiadeyev","emiiiisadl@4564.com","189");
        Sagird t=new Sagird("tohfe","tohfeli","em@4564.com","123189");
        DataBaseConnection.addSagirdToDb(s);
        DataBaseConnection.addSagirdToDb(t);
        System.out.println(DataBaseConnection.checklogin(s.getEmail(),s.getPassword()));
        System.out.println(DataBaseConnection.checklogin("em@4564.com","123189"));

        }
    }

