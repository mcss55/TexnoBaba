package com.mcss.texnobaba;

import java.util.ArrayList;

public class Sagird {
    public String name;
    public static int id;

    public static int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String surname;
    public String email;
    public String password;
    public static ArrayList<Sagird> sagirdlerList =new ArrayList<>();

    public Sagird(String name, String surname, String email, String password) {
        this.id++;
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.password = password;
    }

    public String getName() {
        return name;
    }
    public static void addSagirdler(Sagird sagird){
        sagirdlerList.add(sagird);
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public static ArrayList<Sagird> getSagirdlerList() {
        return sagirdlerList;
    }

    public void setSagirdlerList(ArrayList<Sagird> sagirdlerList) {
        this.sagirdlerList = sagirdlerList;
    }
}
